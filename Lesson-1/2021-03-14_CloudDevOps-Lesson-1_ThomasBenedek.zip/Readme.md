# Lesson 1: Create a static website on AWS
